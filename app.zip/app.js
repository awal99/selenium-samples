
const {Builder, Key, By, Capabilities,until} = require('selenium-webdriver');
const chromeCapabilities = Capabilities.chrome();
chromeCapabilities.set('chromeOptions', {args: ['--headless']});
let browser = new Builder().forBrowser('chrome').withCapabilities(chromeCapabilities).build();

//browser.get("https://www.huobi.com/en-us/topic/primelist/?code=GMPD")

const app=async()=>{
    await browser.get("https://www.huobi.com/en-us/topic/primelist/?code=ERTHA"); //lets get the URL for the sales here
    
	await browser.findElement(By.css("div.right>button[type='default']")).click()

//lets wait until the user login and we identify we are in the login page
       console.warn("Control Returned to human!!!");
       console.warn("Waiting for you to login!!!");
      await browser.wait(until.elementLocated(By.css("div[class='in in-hold']")));

       console.warn("Control Returned to Bot!!!");
       console.warn("Waiting for Redister Button!!!");
   // setTimeout(async()=>{
       await browser.wait(until.elementLocated(By.css("div.right>button[type='default']")))

        const btntoclick = await browser.findElement(By.xpath("//div[@class='right']//button[@type='default']"));
      
            for(let i=0;i<500;i++){
                //if the button is available then lets click it else we break and move to the next item to click
                await btntoclick.click();

                await browser.wait(until.elementIsVisible((await browser).findElement(By.css("div.register-modal"))));
                let exists = await browser.findElements(By.css("div.register-area"));
                //div[@id='modals-container']

                if(exists.length > 0){
                    await (await browser.findElement(By.css(".queue-area div.ui-checkbox>input"))).click();
                    await (await browser.findElement(By.css(".footer>button[type='primary']"))).click();
                   // btntoclick.click();
                   console.info("All Done!!!")
                   return 0;
                }
                // else{
                //     btntoclick.click();
                // }
            }
   // },10000);//place the time remaining here in milliseconds
    
}

app();

